Controls:

WASD to move

LEFT CLICK to shoot primary

RIGHT CLICK to shoot secondary

TAB to open inventory

ESC to open pause menu

Q to use throwables

Known Issues:

Enemies that spawn on the bottom of a room can be hard to see/ get stuck. If this happens use throwables [Q] to hit them 
or use the debug features in the pause menu to progress.

Boss may bug in his decision tree due to faulty reload / rate-of-fire coroutines when he's switching between weapons.

Shopkeeper does not drop the weapons you buy.